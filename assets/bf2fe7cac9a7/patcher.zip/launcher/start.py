# SPDX-License-Identifier: GPL-2.0-or-later
"""Start the deck the way setup configured it (cdj.conf): the CDJ-850 in
one window. Ctrl-C stops everything.

  usage: ./start.sh             start
         ./start.sh --model <id>   start that player (cdj850, the default;
                                 see models/); setup.sh
                                 stores the one you chose in cdj.conf
         ./start.sh --app       start with the virtual deck app as the window
                                 (every player that has a face in app/faces/; a player
                                 without one keeps its plain window)
         ./start.sh --web [lan] serve the deck as a web page as well: on this
                                 PC only, or with "lan" on its LAN address with
                                 a key made at each start in the printed URL
                                 (not drawn for the CDJ-850 yet)
         ./start.sh --service   boot into the service manual's SERVICE MODE
                                 screen instead of the player (see "Service
                                 mode" in docs/using-the-deck.md)
         ./start.sh stop        stop a running rig from another shell
         ./start.sh --dry-run   show what would be started
  env:   every knob of scripts/run/rig.sh still works (AUDIODEV=, NOSOUND=1,
         GUI_DISPLAY=, PRIO=, TBFAST=0, ...).
"""

import glob
import ipaddress
import os
import secrets
import shlex
import shutil
import signal
import subprocess
import sys
import time

from . import chain, conf, deck, firmware, host, model, mods, sites
from .chain import nonempty, say
from .console import stdin_is_tty
from .layout import Layout


def _python_cmd(value, default=()):
    """A recorded Python: an absolute path (possibly with spaces, possibly an
    MSYS2 /c/... one) or a command such as "py -3"."""
    if not value:
        return list(default)
    if host.is_file(host.native(value)):
        return [host.native(value)]
    argv = shlex.split(value)
    return argv if argv and shutil.which(argv[0]) else []


def _app_python(lay, c, web=False):
    """The Python the virtual deck app (or with `web`, the web deck, which
    needs no pygame) runs on, or None once it has said what that Python lacks.
    setup installs Pillow and pygame into .venv/, so the app runs there when it
    exists; this interpreter is for setups without one."""
    venv = os.path.join(lay.emu, ".venv", "bin", "python")
    app_py = _python_cmd(c["CDJ_APP_PYTHON"],
                         [venv] if os.access(venv, os.X_OK) else host.python_argv())
    need = "PIL" if web else "pygame, PIL"
    if not lay.packaged and subprocess.run(app_py + ["-c", "import " + need],
                                           capture_output=True).returncode:
        if web:
            chain.err("the web deck needs Pillow in %s:" % " ".join(app_py))
            chain.err("  %s -m pip install Pillow" % " ".join(app_py))
            return None
        chain.err("the virtual deck app needs pygame-ce and Pillow in %s:" % " ".join(app_py))
        chain.err("  %s -m pip install -r requirements.txt   (or: pygame-ce Pillow)" % " ".join(app_py))
        chain.err("or run without --app (the plain deck windows).")
        return None
    return app_py


def _vnc_screens(lay, env, decks):
    """Each deck's screen to a VNC server on loopback and a frame file, for
    the app and the web deck to draw."""
    env["GUI_DISPLAY"] = "vnc"
    vnc_want = int(nonempty(env, "CDJ_APP_VNC_BASE", "5920"))
    # A port another program (or a leftover QEMU) holds makes the display
    # board's QEMU exit at once, and the app then waits for its screen forever.
    vnc_base = host.pick_port_block(vnc_want, int(decks))
    if vnc_base != vnc_want:
        say("TCP %d+ is reserved or in use here; the deck app's VNC screens use %d+ instead" % (
            vnc_want, vnc_base))
    env["CDJ_APP_VNC_BASE"] = str(vnc_base)
    # Both QEMU and a Windows Python want a native path here.
    env["CDJ_APP_FRAME_DIR"] = env.get("CDJ_APP_FRAME_DIR") or (
        host.native(env["TMPDIR"]) if env.get("TMPDIR") else lay.tmp)


WEB_PORT = 7210


def _web_command(lay, c, env, decks, web):
    """(argv, URL) of the web deck; `web` is "1" (this PC) or "lan". None
    once it has said why it cannot run."""
    py = _app_python(lay, c, web=True)
    if py is None:
        return None
    bind = "127.0.0.1"
    if web == "lan":
        bind = host.lan_address()
        if bind is None or not ipaddress.ip_address(bind).is_private:
            chain.err("--web lan: this PC has no private LAN address (%s); try --web alone" % bind)
            return None
        env["CDJ_WEB_TOKEN"] = secrets.token_urlsafe(16)
        if host.is_windows():
            say("Windows may ask whether Python may use the network: allow it on private networks.")
    port = host.pick_tcp_port(WEB_PORT)
    argv = py + [os.path.join(lay.emu, "app", "web_deck.py"), "--decks", decks, "--prefix", c["CDJ_NAME"],
                 "--relay", "127.0.0.1:" + env["RELAY_PORT"], "--vnc-base", env["CDJ_APP_VNC_BASE"],
                 "--frame-dir", env["CDJ_APP_FRAME_DIR"], "--bind", bind, "--port", str(port)]
    url = "http://%s:%d/" % (bind, port)
    if web == "lan":
        url += "?k=" + env["CDJ_WEB_TOKEN"]
    return argv, url


def _stale_builds(lay, env):
    """Build trees older than the board sources, judged by
    scripts/build/source_stamp.sh, which build.sh stamps them with."""
    bash = host.find_bash()
    if lay.packaged or not bash:
        return []
    script = '. "%s"; CDJ_EMU_DIR="%s"; cdj_stale_builds' % (
        host.posix(os.path.join(lay.scripts, "build", "source_stamp.sh")), host.posix(lay.emu))
    out = subprocess.run([bash, "-c", script], env=env, capture_output=True, text=True).stdout
    return [line for line in out.splitlines() if line.strip()]


def _offer_rebuild(lay, env, dry):
    """The boards and patches are compiled into the QEMU binaries, so after a
    pull that changed them the decks would run the old code. Offers the
    rebuild; False only when one ran and failed. STALE_CHECK=0 skips it."""
    if env.get("STALE_CHECK", "1") != "1":
        return True
    stale = _stale_builds(lay, env)
    if not stale:
        return True
    say("the emulator's source has changed since it was last built:")
    for s in stale:
        say("    " + s)
    ans = None
    if not dry and stdin_is_tty():
        # MSYS reports /dev/null as a terminal, so the prompt can still hit EOF.
        try:
            ans = input("rebuild now (a few minutes)? [Y/n] ").strip() or "y"
        except EOFError:
            print()
    if ans is None:
        say("run ./build.sh main display to pick the changes up")
    elif ans[:1] in "Yy":
        return subprocess.run([host.find_bash(), host.posix(os.path.join(lay.emu, "build.sh")),
                               "main", "display"], env=env).returncode == 0
    else:
        say("starting the old build (./build.sh main display rebuilds it)")
    return True


def _offer_faster_module(lay, player, env, dry):
    return


def stop(lay):
    """Ask every running rig to stop its decks in order, then end any QEMU
    that is still there."""
    requests = []
    for f in glob.glob(os.path.join(lay.tmp, "cdj-stop-*")):
        open(f, "a").close()
        requests.append(f)
    deadline = time.time() + 75
    while any(os.path.exists(f) for f in requests) and time.time() < deadline:
        time.sleep(0.5)
    if host.is_windows():
        subprocess.run(["taskkill", "/F", "/IM", "qemu-system-sh4.exe", "/IM", "qemu-system-sh4eb.exe"],
                       capture_output=True)
    else:
        subprocess.run(["pkill", "-x", "qemu-system-sh4"], capture_output=True)
        subprocess.run(["pkill", "-f", "qemu-system-sh4eb"], capture_output=True)
    say("stopped.")
    return 0


def main(argv):
    dry, app, service, model_id, web = False, None, None, "", ""
    args = iter(argv)
    for a in args:
        if a == "stop":
            return stop(Layout())
        if a == "--dry-run":
            dry = True
        elif a == "--app":
            app = True
        elif a == "--no-app":
            app = False
        elif a == "--web":
            web = "1"
        elif a == "lan" and web:
            web = "lan"
        elif a == "--service":
            service = True
        elif a == "--no-service":
            service = False
        elif a == "--model":
            model_id = next(args, "")
            if not model_id:
                chain.err("--model needs a player (one of: %s)" % " ".join(model.list_models()))
                return 2
        elif a in ("-h", "--help"):
            sys.stdout.write(__doc__[__doc__.index("  usage:"):])
            return 0
        else:
            chain.err("unknown argument: %s (./start.sh --help)" % a)
            return 2
    lay = Layout()
    if not os.path.isfile(lay.conf):
        chain.err("no cdj.conf yet -- run ./setup.sh first (it builds, prepares the firmware")
        chain.err("and the USB stick, and asks how you want the decks set up).")
        return 1
    values = conf.load(lay.conf, warn=chain.err)
    c = conf.with_start_defaults(values)
    try:
        player = model.load(model_id or c["CDJ_MODEL"] or None)
    except model.ModelError as e:
        chain.err(str(e))
        return 2
    differ = firmware.differing_images(model.extract_dir(lay, player), player)
    off = sites.find(lay, player).switched_off(player)
    if differ or off:
        chain.warn_banner("The installed firmware is not the supported update (unsupported, may not boot):",
                          *(["Not the v%s images: %s" % (player.fw_version, " ".join(differ))] if differ else []),
                          *(["Switched off for it:"] + ["  - " + line for line in off] if off else []))
    if not player.is_rig:
        if app and not player.app_face:
            say("the virtual deck app has no face for the %s yet; starting its plain window" % player.title)
        use_app = c["CDJ_APP"] == "1" if app is None else app
        if web:
            say("the web deck does not draw the %s yet; starting it without the web page" % player.title)
        return _start_deck(lay, player, c, dry, use_app and bool(player.app_face))
    if app is None:
        # The packaged program's window is the virtual deck app unless the
        # settings say otherwise.
        app = c["CDJ_APP"] == "1" or (lay.packaged and "CDJ_APP" not in values)
    if service is None:
        service = nonempty(os.environ, "SERVICE", "0") == "1" or c["CDJ_SERVICE"] == "1"
    env = dict(os.environ)
    env["SERVICE"] = "1" if service else "0"
    # mods.apply applies every mod's own cdj.conf choice (high_fps,
    # live_clock, ...) unless the caller's own environment already set that
    # knob. SERVICE MODE is not a mod (see above): it has no folder in mods/.
    mods.apply(mods.load(lay, player.id), c, env)
    for k in ("QEMU_BUILD", "QEMU_EB_BUILD"):
        if c[k]:
            env[k] = c[k]
    if lay.packaged:
        env["MAIN_QEMU"], env["GUI_QEMU"] = lay.qemu_binaries()
    env.update(RELAY_PORT=c["CDJ_RELAY_PORT"], DJLINK=c["CDJ_DJLINK"], GROUP=c["CDJ_GROUP"])
    # setup.sh already steered CDJ_RELAY_PORT clear of a reserved range, but
    # Windows picks new Hyper-V/WSL ranges on every boot, so the port it chose
    # then can be inside one now. Check again here, not just at setup time.
    if host.is_windows():
        want = int(env["RELAY_PORT"])
        env["RELAY_PORT"] = str(host.pick_tcp_port(want))
        if env["RELAY_PORT"] != str(want):
            say("TCP %s is reserved or in use here; the controller relay uses %s instead" % (
                want, env["RELAY_PORT"]))
    # This is now the port every consumer gets told (below, and live.py's own
    # spawn of the relay): live.py must not re-pick on its own, or a port that
    # drifted between the two checks reaches the app/bridge but not the relay
    # that actually bound (RELAY_PORT_FIXED tells it this one is already good).
    env["RELAY_PORT_FIXED"] = "1"
    # rig.py only warns about Pro DJ Link's own UDP port (it is equality-tested
    # against master's rig.sh, which does the same); steer it here instead, the
    # way setup.sh already does once at setup time.
    if host.is_windows() and env["DJLINK"] == "1":
        host_ip, _, gport = env["GROUP"].rpartition(":")
        fixed = host.pick_udp_port(int(gport))
        if fixed != int(gport):
            say("UDP %s is reserved by Windows; Pro DJ Link uses %d instead" % (gport, fixed))
            env["GROUP"] = "%s:%d" % (host_ip, fixed)
    if c["CDJ_AUDIO"] != "1":
        env["NOSOUND"] = "1"
    # One frame of 24 hours: the rig lives until Ctrl-C and writes nothing per frame.
    for k, v in (("FRAMES", "1"), ("MOTION_MS", "86400000"), ("AUTOLOAD", "0")):
        env[k] = nonempty(env, k, v)
    decks = "2" if c["CDJ_DECKS"] == "2" else "1"
    # Both decks otherwise boot as PLAYER No. 1, and identical claims deadlock
    # Pro DJ Link's device-number negotiation forever (see boot_deck.py). A
    # caller's own PLAYERNO wins; rig.sh/live.sh have no such default, since
    # they are the developer-facing knobs this one sets for a plain start.
    if decks == "2" and env["DJLINK"] == "1":
        env["PLAYERNO"] = nonempty(env, "PLAYERNO", "%N%")
    launch = chain.script_argv("live_linked" if decks == "2" else "live", [c["CDJ_NAME"], decks])

    if not _offer_rebuild(lay, env, dry):
        return 1
    _offer_faster_module(lay, player, env, dry)
    missing = [f for f in ("main_unpacked.bin", "gui_unpacked.bin", "flash.bin")
               if not os.path.isfile(os.path.join(model.extract_dir(lay, player), f))]
    if missing:
        chain.err("missing firmware images: %s -- run ./setup.sh --firmware <%s>"
                  % (" ".join(player.extract + "/" + f for f in missing), player.upd[0]))
        return 1
    if nonempty(env, "MEDIA_MODE", "img") == "img" and not env.get("MEDIA_IMG_SRC") \
            and not os.path.isfile(lay.usb_image):
        chain.err("no USB image yet -- run ./setup.sh --music <your rekordbox USB folder>")
        return 1

    # The virtual deck app (app/virtual_deck.py) and the web deck
    # (app/web_deck.py) replace the display board's QEMU window: each deck's
    # screen goes to a VNC server on loopback and a frame file, and they draw
    # the player around it.
    app_cmd, web_cmd = [], []
    if app or web:
        _vnc_screens(lay, env, decks)
    if web:
        got = _web_command(lay, c, env, decks, web)
        if got is None:
            return 1
        web_cmd, web_url = got
    if app:
        app_py = _app_python(lay, c)
        if app_py is None:
            return 1
        # Where boot_deck.py logs each display board, for the app to point at
        # when a deck's screen never comes.
        env["CDJ_APP_GUI_LOGS"] = host.posix(nonempty(env, "LOGDIR", lay.tmp))
        env["CDJ_APP_LOG"] = env.get("CDJ_APP_LOG") or os.path.join(lay.logs, "app.log")
        app_cmd = app_py + [os.path.join(lay.emu, "app", "virtual_deck.py"), "--decks", decks,
                            "--prefix", c["CDJ_NAME"], "--relay", "127.0.0.1:" + env["RELAY_PORT"],
                            "--vnc-base", env["CDJ_APP_VNC_BASE"], "--frame-dir", env["CDJ_APP_FRAME_DIR"]]
        if player.app_face:
            app_cmd += ["--model", player.app_face]

    # The bridge runs on the Python setup recorded: on Windows a native one.
    bridge = []
    if c["CDJ_CONTROLLER"] != "none":
        py = _python_cmd(c["CDJ_MIDI_PYTHON"], host.python_argv() if lay.packaged else ())
        if not py:
            say("controller '%s' is configured but the Python with mido +" % c["CDJ_CONTROLLER"])
            say("python-rtmidi (%s) is not there; starting" % (c["CDJ_MIDI_PYTHON"] or "none recorded"))
            say("without it (install them, then ./setup.sh)")
        else:
            bridge = py + ["-u", os.path.join(lay.emu, "midi", "bridge.py"), "--controller", c["CDJ_CONTROLLER"],
                           "--relay", "127.0.0.1:" + env["RELAY_PORT"], "--prefix", c["CDJ_NAME"]]

    say("decks: %s (%s)   Pro DJ Link: %s   sound: %s   controller: %s   window: %s%s" % (
        decks, c["CDJ_NAME"], "on " + env["GROUP"] if env["DJLINK"] == "1" else "off",
        "on" if c["CDJ_AUDIO"] == "1" else "off", c["CDJ_CONTROLLER"], "virtual deck app" if app else "browser" if web else "QEMU",
        "   SERVICE MODE" if service else ""))
    if dry:
        say("would run:  RELAY_PORT=%s DJLINK=%s GROUP=%s%s%s%s %s" % (
            env["RELAY_PORT"], env["DJLINK"], env["GROUP"], " NOSOUND=1" if env.get("NOSOUND") == "1" else "",
            " QEMU_BUILD=" + env["QEMU_BUILD"] if env.get("QEMU_BUILD") else "",
            " SERVICE=1" if service else "", _shown(launch)))
        if bridge:
            say("and:        %s > logs/bridge.log" % " ".join(shlex.quote(a) for a in bridge))
        if app_cmd:
            say("with:       GUI_DISPLAY=vnc CDJ_APP_VNC_BASE=%s, then %s"
                % (env["CDJ_APP_VNC_BASE"], " ".join(shlex.quote(a) for a in app_cmd)))
        if web_cmd:
            say("web deck:   %s > logs/web.log" % " ".join(shlex.quote(a) for a in web_cmd))
        return 0
    if web_cmd:
        say("deck in the browser: %s" % web_url)
    return run(lay, env, launch, bridge, app_cmd, web_cmd)


def _start_deck(lay, player, c, dry, app=False):
    """The player in one window, MAIN emulator alone (launcher/deck.py). With the
    app, its screen goes to a VNC server and the app draws the player around
    it, sending the drawn keys to the panel socket the host keyboard uses."""
    env = dict(os.environ)
    if lay.packaged:
        env["MAIN_QEMU"] = lay.qemu_binaries()[0]
    elif not env.get("MAIN_QEMU"):
        for k in ("QEMU_BUILD", "QEMU_EB_BUILD"):
            if c[k]:
                env[k] = c[k]
    env.update(DJLINK=c["CDJ_DJLINK"], GROUP=c["CDJ_GROUP"])
    mods.apply(mods.load(lay, player.id), c, env)
    if c["CDJ_AUDIO"] != "1":
        env["NOSOUND"] = "1"
    if not _offer_rebuild(lay, env, dry):
        return 1
    _offer_faster_module(lay, player, env, dry)
    decks = 2 if c["CDJ_DECKS"] == "2" else 1
    if app and decks > 1:
        # The app sends every key to the one panel port it is given.
        say("the virtual deck app drives one older deck so far; starting the %d plain windows" % decks)
        app = False
    app_cmd = []
    if app:
        app_py = _app_python(lay, c)
        if app_py is None:
            return 1
        vnc_want = int(nonempty(env, "CDJ_APP_VNC_BASE", "5920"))
        vnc_base = host.pick_port_block(vnc_want, 1)
        if vnc_base != vnc_want:
            say("TCP %d+ is reserved or in use here; the deck app's VNC screen uses %d+ instead" % (
                vnc_want, vnc_base))
        env["GUI_DISPLAY"] = "vnc=127.0.0.1:%d" % (vnc_base + 1 - 5900)
        env["CDJ_PANEL_KEYSOCK"] = nonempty(env, "CDJ_PANEL_KEYSOCK", str(host.pick_udp_port(deck.PANEL_KEY_PORT)))
        env["CDJ_PANEL_STATESOCK"] = nonempty(env, "CDJ_PANEL_STATESOCK",
                                              str(host.pick_udp_port(deck.PANEL_STATE_PORT)))
        env["CDJ_APP_LOG"] = env.get("CDJ_APP_LOG") or os.path.join(lay.logs, "app.log")
        app_cmd = app_py + [os.path.join(lay.emu, "app", "virtual_deck.py"), "--model", player.app_face,
                            "--decks", "1", "--prefix", c["CDJ_NAME"], "--vnc-base", str(vnc_base),
                            "--panel-port", env["CDJ_PANEL_KEYSOCK"], "--state-port", env["CDJ_PANEL_STATESOCK"]]
    return deck.start(player, env, dry, app_cmd, decks)


def _shown(argv):
    if os.path.basename(argv[0]).startswith("bash"):
        argv = ["bash"] + argv[1:]
    return " ".join(argv)


def run(lay, env, launch, bridge, app_cmd, web_cmd=()):
    os.makedirs(lay.logs, exist_ok=True)
    env["LAUNCHER_STOP_FILE"] = "%s/cdj-stop-%d" % (lay.tmp, os.getpid())
    env = chain.launcher_env(env)
    stop = lambda *_: open(env["LAUNCHER_STOP_FILE"], "a").close()
    signal.signal(signal.SIGINT, stop)
    if hasattr(signal, "SIGHUP"):
        signal.signal(signal.SIGHUP, lambda *_: chain.hangup(stop))
    helpers = []
    try:
        if bridge:
            # The bridge reconnects on its own, so it can start before the relay is up.
            with open(os.path.join(lay.logs, "bridge.log"), "wb") as log:
                helpers.append(subprocess.Popen(bridge, stdout=log, stderr=subprocess.STDOUT))
            say("controller bridge running (log: logs/bridge.log)")
        if web_cmd:
            with open(os.path.join(lay.logs, "web.log"), "wb") as log:
                helpers.append(subprocess.Popen(web_cmd, env=env, stdout=log, stderr=subprocess.STDOUT))
        if env["SERVICE"] == "1":
            say("the first boot takes a minute; SERVICE MODE appears once the logo clears.")
        else:
            say("the first boot takes a minute; then press USB (or LINK) to browse, load a track and play.")
        if not app_cmd:
            return subprocess.Popen(launch, env=env).wait()
        # With the app, the rig runs behind it and lives as long as its window:
        # closing the window or Ctrl-C stops the decks.
        with open(os.path.join(lay.logs, "rig.log"), "wb") as log:
            rig = subprocess.Popen(launch, env=env, stdout=log, stderr=subprocess.STDOUT)
        say("decks starting (logs: logs/rig.log, logs/app.log); the virtual deck window opens now.")
        window = subprocess.Popen(app_cmd, env=env)
        while window.poll() is None and rig.poll() is None and not os.path.exists(env["LAUNCHER_STOP_FILE"]):
            time.sleep(0.5)
        open(env["LAUNCHER_STOP_FILE"], "a").close()
        if window.poll() is None:
            window.terminate()
        rig.wait()
        say("stopped.")
        return 0
    finally:
        for p in helpers:
            p.terminate()
        chain.remove(env["LAUNCHER_STOP_FILE"])
